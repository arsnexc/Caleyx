(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  const hdr = $("#hdr");
  const onScroll = () => hdr && hdr.classList.toggle("scrolled", window.scrollY > 8);
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  const tgl = $("#navTgl");
  const closeMenu = () => {
    document.body.classList.remove("menu-open");
    if (tgl) tgl.setAttribute("aria-expanded", "false");
  };
  if (tgl) {
    tgl.addEventListener("click", () => {
      const open = document.body.classList.toggle("menu-open");
      tgl.setAttribute("aria-expanded", String(open));
    });
    $$("#mnav a").forEach((a) => a.addEventListener("click", closeMenu));
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeMenu();
    });
  }

  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          en.target.classList.add("is-in");
          io.unobserve(en.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
  );
  $$("[data-reveal]").forEach((el) => io.observe(el));

  let cartCount = 0;
  const ct = $("#ct");
  const bumpCart = () => {
    cartCount += 1;
    if (!ct) return;
    ct.textContent = String(cartCount);
    const parent = ct.closest("[aria-label]");
    if (parent) parent.setAttribute("aria-label", `Cart, ${cartCount} items`);
    ct.classList.remove("pop");
    void ct.offsetWidth;
    ct.classList.add("pop");
  };

  $$("[data-add]").forEach((btn) => {
    const original = btn.textContent;
    btn.addEventListener("click", () => {
      bumpCart();
      btn.classList.add("added");
      btn.textContent = "Added";
      btn.disabled = true;
      setTimeout(() => {
        btn.textContent = original;
        btn.classList.remove("added");
        btn.disabled = false;
      }, 1600);
    });
  });

  const price = $("#buyPrice");
  const was = $("#buyWas");
  const save = $("#buySave");
  const onceBtn = $("#planOnce");
  const subBtn = $("#planSub");
  const atcTotal = $("#atcTotal");
  const qtyOut = $("#qtyOut");
  let qty = 1;
  let plan = "once";

  const unit = () => (plan === "sub" ? 28.9 : 34);
  const money = (n) =>
    n.toLocaleString("en-US", { style: "currency", currency: "USD" });

  const renderBuy = () => {
    if (!price) return;
    const u = unit();
    price.textContent = money(u);
    was.classList.toggle("show", plan === "sub");
    save.classList.toggle("show", plan === "sub");
    onceBtn.setAttribute("aria-pressed", String(plan === "once"));
    subBtn.setAttribute("aria-pressed", String(plan === "sub"));
    if (atcTotal) atcTotal.textContent = money(u * qty);
  };

  if (onceBtn && subBtn) {
    onceBtn.addEventListener("click", () => {
      plan = "once";
      renderBuy();
    });
    subBtn.addEventListener("click", () => {
      plan = "sub";
      renderBuy();
    });
  }

  const setQty = (n) => {
    qty = Math.min(6, Math.max(1, n));
    if (qtyOut) qtyOut.textContent = String(qty);
    renderBuy();
  };
  const minus = $("#qtyMinus");
  const plus = $("#qtyPlus");
  if (minus) minus.addEventListener("click", () => setQty(qty - 1));
  if (plus) plus.addEventListener("click", () => setQty(qty + 1));

  $$(".acc").forEach((acc) => {
    const btn = $(".acc-btn", acc);
    const panel = $(".acc-panel", acc);
    if (!btn || !panel) return;
    btn.addEventListener("click", () => {
      const open = acc.classList.toggle("open");
      btn.setAttribute("aria-expanded", String(open));
      panel.style.maxHeight = open ? panel.scrollHeight + "px" : "0px";
    });
  });

  const stage = $("#stage");
  $$(".thumb[data-view]").forEach((t) => {
    t.addEventListener("click", () => {
      if (!stage) return;
      stage.dataset.view = t.dataset.view;
      $$(".thumb").forEach((x) => x.setAttribute("aria-current", "false"));
      t.setAttribute("aria-current", "true");
    });
  });

  const form = $("#newsForm");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      form.style.display = "none";
      const done = $("#newsDone");
      if (done) done.style.display = "block";
    });
  }
})();
